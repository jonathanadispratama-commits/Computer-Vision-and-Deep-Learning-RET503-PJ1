# Praktik Terpadu YOLO: Jonathan Adis Pratama (4222401018)

## Dataset

- Sumber: gambar `panah` dari Roboflow (image detection v12, format YOLOv8), sedangkan gambar `huruf_angka` dibuat sendiri secara sintetis (huruf/angka ditempel pada latar acak, kotak label dibuat otomatis). Keduanya digabung menjadi satu dataset deteksi.
- 2 kelas: `panah` (0) dan `huruf_angka` (1). Dibagi train/val/test = 732/162/100 gambar (sekitar 74/16/10).
- Model dasar: `yolov8n`, epoch 50, imgsz 320, batch 16, seed 0. Perubahan E3: `imgsz=640`.

![Contoh gambar dataset dengan kotak label](gambar/cek_dataset.png)

## Hasil eksperimen (data VAL)

| eksperimen     | perubahan | pretrained | mAP50 | mAP50-95 | precision | recall | inferensi_ms | waktu_latih_menit | imgsz |
| -------------- | --------- | ---------- | ----- | -------- | --------- | ------ | ------------ | ----------------- | ----- |
| E1_pretrained  | -         | True       | 0.995 | 0.885    | 0.995     | 1.000  | 2.7          | 5.2               | 320   |
| E2_scratch     | -         | False      | 0.988 | 0.788    | 0.980     | 0.974  | 2.0          | 4.8               | 320   |
| E3_tuning      | imgsz=640 | True       | 0.995 | 0.903    | 0.999     | 0.996  | 5.8          | 9.0               | 640   |

## Hasil uji (data TEST, sekali saja)

- Model terpilih (mAP50-95 val tertinggi): E3_tuning
- Hasil di data TEST (sekali saja): mAP50 0.990 | mAP50-95 0.893

## Analisis

### 1. Ringkasan

Praktik ini membandingkan tiga eksperimen YOLO (model `yolov8n`, sekitar 3,01 juta parameter) untuk mendeteksi objek `panah` dan `huruf_angka`. Model pretrained dengan `imgsz=640` (E3) menjadi yang terbaik dengan mAP50-95 0,903 pada data validasi dan 0,893 pada data test. Model pretrained `imgsz=320` (E1) mencapai 0,885, sedangkan model tanpa transfer learning (E2) hanya 0,788. Perbedaan terbesar datang dari transfer learning (selisih 0,097), sedangkan memperbesar ukuran gambar memberi tambahan kecil (0,018) dengan biaya inferensi dua kali lebih lambat.

### 2. Dataset dan pengaturan

Dataset terdiri dari 994 gambar dengan dua kelas: `panah` (498 objek) dan `huruf_angka` (763 objek, gabungan beberapa huruf dan angka menjadi satu kelas). Jumlah gambar per kelas seimbang di setiap split (separuh gambar berisi panah, separuh berisi huruf/angka):

| Bagian | Gambar | Gambar panah | Gambar huruf_angka | Objek panah | Objek huruf_angka |
| ------ | ------ | ------------ | ------------------ | ----------- | ----------------- |
| train  | 732    | 366          | 366                | 367         | 569               |
| val    | 162    | 81           | 81                 | 81          | 124               |
| test   | 100    | 50           | 50                 | 50          | 70                |

Gambar `huruf_angka` bisa berisi lebih dari satu objek (misalnya 569 objek pada 366 gambar train), sedangkan gambar `panah` hampir selalu satu objek. Seluruh eksperimen memakai pengaturan yang sama (50 epoch, batch 16, imgsz 320, seed 0, GPU Tesla T4, Ultralytics 8.4.178), kecuali yang sengaja diubah pada E2 (tanpa bobot pretrained) dan E3 (imgsz 640).

### 3. Cara membaca metrik

mAP50 menghitung ketepatan deteksi dengan syarat kotak prediksi tumpang tindih minimal 50% dengan kotak sebenarnya, sedangkan mAP50-95 merata-ratakan ketepatan pada ambang tumpang tindih 50% sampai 95% sehingga menuntut kotak yang jauh lebih presisi. Pada dataset ini mAP50 E1 dan E3 sudah jenuh di 0,995, sehingga tidak bisa membedakan keduanya. Karena itu mAP50-95 dijadikan penentu pemilihan model, sedangkan precision dan recall dipakai sebagai pelengkap.

### 4. E1 (pretrained) vs E2 (scratch)

Pada data validasi, E1 mencapai mAP50-95 0,885 dan E2 0,788, selisih sekitar 0,097. Selisih ini terlihat jelas pada kecepatan belajar. E1 sudah mencapai mAP50-95 0,66 pada epoch 1 dan melewati 0,80 pada epoch 10. E2 baru 0,15 pada epoch 5, baru melewati 0,50 pada epoch 11, dan sampai epoch 50 belum pernah mencapai 0,80 (akhir pelatihan sekitar 0,79). Nilai loss pada epoch 50 mendukung hal ini: box loss E1 0,413 dan cls loss 0,260, sedangkan E2 masih 0,770 dan 0,519. Kurva E2 masih naik di akhir pelatihan, sehingga E2 belum konvergen dalam 50 epoch, dan dugaan saya selisihnya dapat mengecil bila E2 dilatih lebih lama (belum diuji).

Penyebabnya adalah transfer learning. Bobot pretrained dari COCO sudah memuat fitur visual dasar seperti tepi, sudut, warna, dan bentuk, sehingga E1 hanya perlu menyesuaikan diri ke dua kelas baru. E2 harus mempelajari semuanya dari nol hanya dari 732 gambar latih. Pada precision dan recall, E1 (P 0,995; R 1,000) lebih unggul dibanding E2 (P 0,980; R 0,974), artinya E2 lebih sering salah mendeteksi maupun melewatkan objek. Keunggulan E2 hanya pada waktu latih dan inferensi yang sedikit lebih cepat (4,8 vs 5,2 menit; 2,0 vs 2,7 ms), padahal arsitekturnya identik, sehingga selisih ini kemungkinan besar berasal dari variasi pengukuran dan bukan sifat model.

### 5. E3 (tuning imgsz=640)

Perubahan tunggal pada E3 adalah ukuran gambar masukan dari 320 menjadi 640. Hasilnya mAP50-95 0,903, lebih tinggi 0,018 dari E1 (0,885), dengan precision 0,999 dan recall 0,996. Dari log pelatihan, E3 juga satu-satunya yang melewati mAP50-95 0,90 (pada epoch 36). Harganya nyata: waktu inferensi naik dari 2,7 ms menjadi 5,8 ms (sekitar dua kali lipat) dan waktu latih dari 5,2 menjadi 9,0 menit.

Dugaan saya, peningkatan ini terutama karena objek pada sebagian gambar sangat kecil (terlihat pada gambar sampel, terutama panah pada foto lorong), sehingga pada imgsz 320 detailnya hilang saat gambar diperkecil, sedangkan imgsz 640 mempertahankan lebih banyak piksel. Dugaan ini belum diuji (misalnya dengan memisahkan hasil per ukuran objek). Selisih 0,018 juga berasal dari satu kali percobaan per eksperimen, sehingga belum bisa dipastikan sepenuhnya nyata.

### 6. Pemilihan model, hasil uji, dan kelas yang sulit

Model dipilih berdasarkan mAP50-95 tertinggi pada data validasi, yaitu E3 (0,903). Model ini kemudian diuji satu kali pada data test dan memperoleh mAP50 0,990, mAP50-95 0,893, precision 1,000, dan recall 0,992. Nilai test sedikit di bawah validasi (0,893 vs 0,903), hal yang wajar karena model dipilih berdasarkan data validasi dan data test hanya 100 gambar. Selisih sekecil ini tidak menunjukkan overfitting yang berarti. Data test hanya dipakai sekali agar tidak ikut memengaruhi pemilihan model.

**Kelas yang sulit.** Confusion matrix E3 pada data validasi (ambang kepercayaan 0,25; kolom = kelas sebenarnya, baris = prediksi) ditampilkan di bawah ini.

![Confusion matrix E3](E3_tuning/confusion_matrix.png)

Pada data validasi (81 objek `panah` dan 124 objek `huruf_angka`), E3 mendeteksi seluruh 81 `panah` dengan benar dan 123 dari 124 `huruf_angka` (99,2%). Satu objek `huruf_angka` terlewat (terbaca sebagai latar), dan tidak ada kotak berlebih. Tidak ada objek yang tertukar kelasnya. Sebagai pembanding, E1 mendeteksi seluruh 205 objek dengan benar tetapi menghasilkan 5 kotak berlebih (3 berlabel `panah`, 2 berlabel `huruf_angka`), sedangkan E2 melewatkan 5 objek `huruf_angka` dan menghasilkan 14 kotak berlebih (3 `panah`, 11 `huruf_angka`).

Dengan demikian tidak ada kelas yang sering tertukar; kesalahan yang ada hanya berupa objek terlewat atau kotak berlebih. Kesalahan E3 dan sebagian besar kesalahan E2 menimpa kelas `huruf_angka`, sedangkan `panah` selalu terdeteksi. Dugaan saya, `huruf_angka` lebih sulit karena lebih bervariasi (banyak jenis huruf dan angka, warna, ukuran, dan kadang lebih dari satu objek per gambar), tetapi hal ini belum diperiksa pada gambar hasil prediksi. Tidak adanya objek yang tertukar kelas juga mungkin terkait perbedaan gaya gambar kedua kelas (lihat bagian keterbatasan). Angka di atas dihitung pada ambang kepercayaan 0,25 dan IoU 0,45, sehingga tidak menilai seberapa pas kotaknya. Selisih mAP50-95 antara E1 (0,885) dan E3 (0,903) kemungkinan berasal dari kotak yang lebih pas pada E3, tetapi ini belum diuji.

Perlu dicatat bahwa kelas `huruf_angka` menggabungkan beberapa jenis huruf dan angka menjadi satu kelas, sehingga model tidak perlu membedakan antar huruf; tugas ini lebih mudah daripada mengenali tiap huruf secara terpisah.

### 7. Keterbatasan dan saran

- **mAP50 sudah jenuh** di sekitar 0,99 sehingga tidak lagi membedakan model. Diperlukan data yang lebih sulit, misalnya latar yang rumit, objek berdempetan, dan pencahayaan yang bervariasi.
- **Gambar `huruf_angka` dan `panah` berasal dari sumber yang berbeda.** Huruf/angka berupa gambar sintetis (ditempel pada latar polos atau berpola), sedangkan panah berupa foto nyata di lorong atau lantai. Model bisa saja ikut memanfaatkan perbedaan gaya latar ini, bukan hanya bentuk objek, sehingga nilai yang tinggi belum tentu berlaku pada foto huruf/angka nyata. Sebaiknya diuji dengan foto huruf/angka dan panah yang diambil di lingkungan yang sama.
- **Pembagian train/val/test belum diperiksa kebocorannya.** Gambar yang hampir kembar (misalnya hasil augmentasi atau foto berurutan) bisa tersebar di beberapa bagian dan membuat nilai terlihat lebih tinggi. Pembagian berdasarkan sesi foto akan lebih aman.
- **Satu kali percobaan per eksperimen.** Selisih kecil seperti E1 vs E3 (0,018) belum bisa dipastikan nyata. Sebaiknya diulang dengan beberapa seed dan dilaporkan rata-rata serta simpangannya.
- **E2 belum konvergen** dalam 50 epoch. Menambah epoch (misalnya 100) akan memberi perbandingan yang lebih adil antara pretrained dan scratch.
- **Data test kecil** (100 gambar, 50 per kelas), sehingga satu kesalahan saja dapat menggeser metrik per kelas.

### 8. Kesimpulan

Transfer learning terbukti mempercepat konvergensi dan memberi mAP50-95 yang jauh lebih tinggi dibanding melatih dari nol (0,885 vs 0,788). Memperbesar ukuran gambar menjadi 640 memberi tambahan kecil (0,903) dengan waktu inferensi dua kali lebih lambat. Model E3 dipilih dan memberi hasil test mAP50 0,990 dan mAP50-95 0,893 dengan kecepatan inferensi sekitar 5,8 ms per gambar pada GPU T4, masih cukup cepat untuk penggunaan waktu nyata pada dataset ini. Jika kecepatan lebih penting daripada selisih 0,018 mAP50-95, E1 (2,7 ms) adalah alternatif yang masuk akal.

## Isi repositori

| Berkas | Keterangan |
| ------ | ---------- |
| `README.md` | Hasil eksperimen, hasil test, dan analisis (Read.Me) |
| `hasil_praktik_4222401018.txt` / `.csv` | Ringkasan hasil E1-E3 dari skrip `06_latih_bandingkan.py` |
| `E1_pretrained/results.png`, `E3_tuning/results.png` | Grafik pelatihan E1 dan E3 (E2 juga disertakan di `E2_scratch/`) |
| `E1_pretrained/`, `E2_scratch/`, `E3_tuning/` → `confusion_matrix.png` | Confusion matrix tiap eksperimen pada data val (`conf=0.25`); E3 adalah model terpilih |
| `pj1_YOLO_JOOJO.ipynb` | Notebook Colab lengkap |
